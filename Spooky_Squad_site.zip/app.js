(() => {
'use strict';

/* ---------- Données ---------- */
const THEMES = {
  vampire:  { nom:'La Famille Vampire', court:'Vampire', tag:'Tendance n°1', txt:'Capes à haut col, doublure rouge, crocs fournis. Le thème le plus demandé de l’année, de papa au chien.' },
  sorcieres:{ nom:'Les Sorcières', court:'Sorcières', tag:'Top adultes', txt:'Chapeaux pointus, capes étoilées, collants rayés. Un classique qui marche à tous les âges.' },
  potager:  { nom:'Le Potager', court:'Potager', tag:'Top animaux', txt:'Citrouille toute douce, épouvantail, épi de maïs. Le costume animal le plus porté est… la citrouille.' },
  olympe:   { nom:'L’Olympe', court:'Olympe', tag:'Nouveau', txt:'Toges drapées et couronnes de laurier dorées. Dieux, déesses et héros grecs, pour une bande qui a de l’allure.' },
  monstres: { nom:'Les Monstres classiques', court:'Monstres', tag:'Classique', txt:'Momie, monstre recousu, loup-garou. Les grands monstres du cinéma, en version rigolote.' },
  gothique: { nom:'La Famille gothique', court:'Gothique', tag:'Culte', txt:'Rayures noires, cols blancs, tresses et teint pâle. Une famille étrange, élégante et très photogénique.' }
};
const ROLES = { adulte:'Adulte', enfant:'Enfant', animal:'Animal' };
const TAILLES = {
  adulte:['XS','S','M','L','XL','XXL'],
  enfant:['2-3 ans','4-5 ans','6-7 ans','8-9 ans','10-12 ans'],
  animal:['XS','S','M','L']
};
const P = [];
const def = (theme, role, nom, prix, note, avis, desc) => P.push({ id: theme + '-' + role, theme, role, nom, prix, note, avis, desc, img: ({ adulte:'a-', enfant:'e-', animal:'c-' })[role] + theme });
def('vampire','adulte','Costume Comte Nocturne',49,4.8,212,'Cape longue à col montant, doublure rouge satinée, gilet et jabot. Crocs en silicone souple fournis.');
def('vampire','enfant','Petit Comte Nocturne',29,4.9,318,'La même cape en version enfant, fermeture scratch (pas de cordon au cou), crocs taille enfant.');
def('vampire','animal','Cape de vampire pour animal',19,4.7,176,'Cape légère à col montant, fixation scratch sous le poitrail. Ne couvre ni les yeux ni les oreilles.');
def('sorcieres','adulte','Robe de sorcière Étoilée',45,4.8,164,'Robe évasée, cape étoilée violette et chapeau pointu rigidifié. Balai en option.');
def('sorcieres','enfant','Petite sorcière Étoilée',27,4.9,241,'Robe, cape étoilée réfléchissante et chapeau qui tient tout seul. Se lave en machine à 30 °C.');
def('sorcieres','animal','Chapeau et cape de sorcière pour animal',17,4.6,122,'Mini chapeau à élastique doux et cape étoilée. Poids plume, l’animal l’oublie en deux minutes.');
def('potager','adulte','Épouvantail des champs',39,4.7,98,'Salopette rapiécée, chemise à carreaux, chapeau de paille et touffes de raphia. Confortable toute la soirée.');
def('potager','enfant','Citrouille toute douce',24,4.9,356,'Combinaison citrouille rembourrée, bonnet tige. Chaude pour les soirées fraîches de porte en porte.');
def('potager','animal','Costume citrouille pour animal',19,4.8,287,'Le costume animal le plus populaire. Harnais intégré, ouverture pour la laisse.');
def('olympe','adulte','Toge de l’Olympe',42,4.7,87,'Toge drapée en jersey fluide, ceinture et couronne de laurier dorées. Taille unique ajustable par pression.');
def('olympe','enfant','Petite toge de l’Olympe',26,4.8,103,'Toge enfant avec sous-tunique, couronne de laurier souple sans pointes.');
def('olympe','animal','Couronne de laurier et cape pour animal',15,4.6,64,'Cape blanche drapée et petite couronne dorée sur bandeau réglable.');
def('monstres','adulte','Le Monstre recousu',55,4.7,74,'Veste rapiécée, fausses coutures, boulons en mousse et kit de maquillage vert à l’eau.');
def('monstres','enfant','Momie câline',32,4.8,149,'Combinaison bandelettes cousues (rien ne se défait), capuche. Bandes réfléchissantes intégrées.');
def('monstres','animal','Loup-garou pour animal',22,4.7,91,'Capuche oreilles de loup et collerette en fausse fourrure. Oreilles de l’animal libres.');
def('gothique','adulte','Costume gothique à rayures',59,4.8,112,'Costume ou robe à fines rayures, col blanc amovible. Chic pour la soirée, drôle pour les photos.');
def('gothique','enfant','Petite robe gothique à col blanc',34,4.9,188,'Robe noire à col Claudine blanc ou costume rayé garçon. Tresses postiches en option.');
def('gothique','animal','Col et nœud gothique pour animal',15,4.7,79,'Grand col blanc et nœud noir. L’accessoire le plus simple, et le plus efficace en photo.');

const ACCS = [
  { id:'acc-bandes', nom:'Bandes réfléchissantes ×4', prix:6 },
  { id:'acc-seau', nom:'Seau-lampe citrouille', prix:14 },
  { id:'acc-maquillage', nom:'Kit maquillage à l’eau', prix:12 },
  { id:'acc-frontale', nom:'Lampe frontale enfant', prix:9 }
];

const byId = id => P.find(p => p.id === id) || ACCS.find(a => a.id === id);
const HALLOWEEN = new Date(2026, 9, 31), LIM_STD = new Date(2026, 9, 26, 23, 59), LIM_EXP = new Date(2026, 9, 29, 12);
const SEUIL = 60, PORT_STD = 4.9, PORT_EXP = 9.9, PRIX_ANIMAL = 9;

/* ---------- Utilitaires ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const eur = n => (Math.round(n * 100) / 100).toLocaleString('fr-FR', { style:'currency', currency:'EUR', minimumFractionDigits: Math.round(n * 100) % 100 ? 2 : 0 }).replace(/\u202f/g, '\u00a0');
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' }[c]));
const jour = d => d.toLocaleDateString('fr-FR', { weekday:'long', day:'numeric', month:'long' });
const ouvres = (d, n) => { const r = new Date(d); let k = 0; while (k < n) { r.setDate(r.getDate() + 1); const w = r.getDay(); if (w && w !== 6) k++; } return r; };
const joursAvant = () => { const a = new Date(); a.setHours(0,0,0,0); return Math.max(0, Math.round((HALLOWEEN - a) / 864e5)); };
const etoiles = (n, a) => `<span class="etoiles" aria-label="Note ${String(n).replace('.', ',')} sur 5, ${a} avis"><b aria-hidden="true">★★★★★</b> ${String(n).replace('.', ',')} (${a})</span>`;
const ico = {
  plus:'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',
  plusS:'<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',
  moins:'<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M5 12h14"/></svg>',
  x:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>',
  echange:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 7h11l-3-3M17 17H6l3 3"/></svg>',
  camion:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h11v10H3zM14 10h4l3 3v3h-7"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17.5" cy="17.5" r="1.8"/></svg>',
  machine:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><rect x="4" y="3" width="16" height="18" rx="2"/><circle cx="12" cy="13" r="4.5"/><path d="M7 6.5h.01M10 6.5h.01"/></svg>',
  coche:'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  cadenas:'<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>'
};
const img = (n, alt, eager = false, w = 800, h = 1200) => `<img src="img/${n}.webp" alt="${esc(alt)}" ${eager ? 'fetchpriority="high"' : 'loading="lazy"'} decoding="async" width="${w}" height="${h}">`;

/* ---------- Panier et remise de groupe ---------- */
const panier = []; // {cle, id, taille, qte}
const estCostume = l => !l.id.startsWith('acc-');
function calcul() {
  const cost = panier.filter(estCostume);
  const nb = cost.reduce((s, l) => s + l.qte, 0);
  const humains = cost.filter(l => byId(l.id).role !== 'animal').reduce((s, l) => s + l.qte, 0);
  const taux = nb >= 4 ? .25 : nb >= 3 ? .15 : 0;
  let animauxPromo = humains >= 2 ? 2 : 0;
  let brut = 0, net = 0;
  const lignes = panier.map(l => {
    const p = byId(l.id); const b = p.prix * l.qte; let n;
    if (!estCostume(l)) n = b;
    else if (p.role === 'animal') { const k = Math.min(l.qte, animauxPromo); animauxPromo -= k; n = k * PRIX_ANIMAL + (l.qte - k) * p.prix * (1 - taux); }
    else n = b * (1 - taux);
    brut += b; net += n;
    return { l, p, brut: b, net: n };
  });
  return { nb, humains, taux, brut, net, lignes, eco: brut - net };
}
const nbArticles = () => panier.reduce((s, l) => s + l.qte, 0);
function ajouter(id, taille, qte = 1, ouvrir = true) {
  const p = byId(id); taille = taille || (p.role ? TAILLES[p.role][Math.floor(TAILLES[p.role].length / 2)] : '');
  const cle = id + '#' + taille; const l = panier.find(x => x.cle === cle);
  if (l) l.qte += qte; else panier.push({ cle, id, taille, qte });
  majCompteur(true); rendrePanier(); if (ouvrir) ouvrirPanier();
}
function majCompteur(pop) { const n = $('#panier-n'); n.textContent = nbArticles(); if (pop) { n.classList.remove('pop'); void n.offsetWidth; n.classList.add('pop'); } }
const msgPalier = (nb, humains) => {
  if (nb === 0) return 'Ajoutez 3 costumes pour obtenir −15 %.';
  if (nb === 1) return 'Plus que 2 costumes pour −15 %.';
  if (nb === 2) return 'Plus qu’1 costume pour −15 %.';
  if (nb === 3) return '−15 % activé. Ajoutez 1 costume pour passer à −25 %.';
  return '−25 % activé sur toute la bande.' + (humains >= 2 ? ' Animal à 9 €.' : '');
};
const jauge = nb => `<div class="jauge" aria-hidden="true"><i class="${nb >= 1 ? 'on' : ''}"></i><i class="${nb >= 3 ? 'on' : ''}"></i><i class="${nb >= 4 ? 'on' : ''}"></i></div>`;
function rendrePanier() {
  const c = $('#tiroir-corps');
  if (!panier.length) {
    c.innerHTML = `<div class="vide"><h3>Personne n’est encore déguisé</h3><p>Choisissez un thème et ajoutez toute la bande en une fois.</p><a class="btn btn--p" href="#/composer" data-ferme>Composer ma bande</a></div>`;
    return;
  }
  const k = calcul(); const port = k.net >= SEUIL ? 0 : PORT_STD;
  const dans = new Set(panier.map(l => l.id));
  c.innerHTML = `
    <div class="seuil" aria-live="polite"><b>${msgPalier(k.nb, k.humains)}</b>${jauge(k.nb)}</div>
    <div class="lignes">
      ${k.lignes.map(({ l, p, brut, net }) => `
      <div class="ligne">
        ${p.img ? `<img src="img/${p.img}.webp" alt="" width="64" height="78">` : `<span style="width:64px;height:78px;border-radius:8px;background:var(--creme-2);display:grid;place-items:center;font-size:1.6rem" aria-hidden="true">+</span>`}
        <div><h3>${esc(p.nom)}</h3><small>${p.role ? ROLES[p.role] + ' · ' + esc(l.taille) : 'Accessoire'}</small>
          <div class="qte" role="group" aria-label="Quantité"><button data-q="-1" data-cle="${esc(l.cle)}" aria-label="Retirer un">${ico.moins}</button><output>${l.qte}</output><button data-q="1" data-cle="${esc(l.cle)}" aria-label="Ajouter un">${ico.plusS}</button></div>
        </div>
        <div class="ligne__d"><span class="num">${eur(net)}${net < brut - .001 ? `<s class="num" style="display:block">${eur(brut)}</s>` : ''}</span><button data-suppr="${esc(l.cle)}">Retirer</button></div>
      </div>`).join('')}
      <div class="accs"><p>Pour la tournée des bonbons</p><div class="accs__l">${ACCS.filter(a => !dans.has(a.id)).map(a => `<button class="acc-b" data-acc="${a.id}">+ ${esc(a.nom)} · ${eur(a.prix)}</button>`).join('')}</div></div>
    </div>
    <div class="tiroir__pied">
      <div class="tot"><span>Sous-total</span><span class="num">${eur(k.brut)}</span></div>
      ${k.eco > 0 ? `<div class="tot tot--r"><span>Remise de groupe</span><span class="num">−${eur(k.eco)}</span></div>` : ''}
      <div class="tot"><span>Livraison</span><span>${port ? eur(port) : 'Offerte'}</span></div>
      <div class="tot tot--g"><span>Total</span><span class="num">${eur(k.net + port)}</span></div>
      <a class="btn btn--p btn--plein" href="#/commande" data-ferme>Commander</a>
      <p class="securite">${ico.cadenas} Paiement sécurisé · Échange de taille gratuit</p>
    </div>`;
}
function modifier(cle, d) {
  const i = panier.findIndex(x => x.cle === cle); if (i < 0) return;
  panier[i].qte += d; if (panier[i].qte <= 0) panier.splice(i, 1);
  majCompteur(); rendrePanier(); if (location.hash.startsWith('#/commande')) route();
}
let dernierFocus;
function ouvrirPanier() {
  const t = $('#tiroir'), v = $('#voile'); dernierFocus = document.activeElement;
  v.hidden = false; requestAnimationFrame(() => { v.classList.add('vis'); t.classList.add('ouvert'); });
  t.setAttribute('aria-hidden', 'false'); document.body.style.overflow = 'hidden';
  setTimeout(() => $('#fermer-panier').focus(), 50);
}
function fermerPanier() {
  const t = $('#tiroir'), v = $('#voile');
  t.classList.remove('ouvert'); v.classList.remove('vis'); t.setAttribute('aria-hidden', 'true'); document.body.style.overflow = '';
  setTimeout(() => { v.hidden = true; }, 300);
  if (dernierFocus && document.contains(dernierFocus)) dernierFocus.focus();
}
let tt; function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('vis'); clearTimeout(tt); tt = setTimeout(() => t.classList.remove('vis'), 2600); }

/* ---------- Composants ---------- */
const carte = p => `
  <article class="carte rev">
    <a class="carte__img" href="#/produit/${p.id}" tabindex="-1" aria-hidden="true">${img(p.img, '')}${p.role === 'enfant' && p.avis > 200 ? '<span class="badge badge--s">Chouchou des enfants</span>' : p.role === 'animal' && p.theme === 'potager' ? '<span class="badge badge--s">N°1 animaux</span>' : ''}</a>
    <button class="carte__ajout" data-ajout="${p.id}" aria-label="Ajouter ${esc(p.nom)} au panier (taille par défaut)">${ico.plus}</button>
    <div class="carte__info">
      <span class="carte__qui">${ROLES[p.role]} · ${THEMES[p.theme].court}</span>
      <h3 class="carte__nom"><a href="#/produit/${p.id}">${esc(p.nom)}</a></h3>
      <span class="carte__prix num">${eur(p.prix)}</span>
      ${etoiles(p.note, p.avis)}
    </div>
  </article>`;
const prixFamille = th => { const a = byId(th + '-adulte').prix, e = byId(th + '-enfant').prix; return (2 * a + 2 * e) * .75 + PRIX_ANIMAL; };

const guideTailles = () => `
  <div class="bloc-c rev" id="tailles">
    <p class="surtitre">Guide des tailles</p>
    <h2>La bonne taille du premier coup.</h2>
    <p>Entre deux tailles ? Prenez la plus grande : nos costumes se portent sur un pull. Et si ça ne va pas, l’échange est gratuit.</p>
    <div class="onglets" role="tablist" aria-label="Type de taille">
      <button class="onglet" role="tab" aria-selected="true" data-onglet="enfant">Enfants</button>
      <button class="onglet" role="tab" aria-selected="false" data-onglet="adulte">Adultes</button>
      <button class="onglet" role="tab" aria-selected="false" data-onglet="animal">Animaux</button>
    </div>
    <div data-panneau="enfant"><table class="table-t"><thead><tr><th>Taille</th><th>Hauteur</th></tr></thead><tbody>
      <tr><td>2-3 ans</td><td>92 – 98 cm</td></tr><tr><td>4-5 ans</td><td>104 – 110 cm</td></tr><tr><td>6-7 ans</td><td>116 – 122 cm</td></tr><tr><td>8-9 ans</td><td>128 – 134 cm</td></tr><tr><td>10-12 ans</td><td>140 – 152 cm</td></tr></tbody></table>
      <div class="reco"><label for="haut">Taille de l’enfant (cm)</label><input class="champ" id="haut" type="number" inputmode="numeric" min="80" max="160" placeholder="115"><output id="reco-out" aria-live="polite">→ saisissez une hauteur</output></div>
    </div>
    <div data-panneau="adulte" hidden><table class="table-t"><thead><tr><th>Taille</th><th>Tour de poitrine</th></tr></thead><tbody>
      <tr><td>XS</td><td>78 – 84 cm</td></tr><tr><td>S</td><td>84 – 90 cm</td></tr><tr><td>M</td><td>90 – 98 cm</td></tr><tr><td>L</td><td>98 – 106 cm</td></tr><tr><td>XL</td><td>106 – 114 cm</td></tr><tr><td>XXL</td><td>114 – 124 cm</td></tr></tbody></table></div>
    <div data-panneau="animal" hidden><table class="table-t"><thead><tr><th>Taille</th><th>Poids</th><th>Exemple</th></tr></thead><tbody>
      <tr><td>XS</td><td>moins de 4 kg</td><td>Chat, chihuahua</td></tr><tr><td>S</td><td>4 – 8 kg</td><td>Teckel, jack russell</td></tr><tr><td>M</td><td>8 – 15 kg</td><td>Beagle, cocker</td></tr><tr><td>L</td><td>15 – 30 kg</td><td>Labrador, golden</td></tr></tbody></table></div>
  </div>`;
const recoTaille = h => h < 80 || h > 165 || isNaN(h) ? '→ saisissez une hauteur entre 80 et 160 cm' : '→ ' + (h <= 99 ? '2-3 ans' : h <= 111 ? '4-5 ans' : h <= 123 ? '6-7 ans' : h <= 135 ? '8-9 ans' : '10-12 ans');

/* ---------- Pages ---------- */
function pageAccueil() {
  const best = ['vampire-enfant','potager-animal','sorcieres-adulte','gothique-enfant'].map(byId);
  return `
  <section class="hero" aria-labelledby="h-hero">
    <div class="hero__in">
      ${img('hero', 'Une famille de quatre et leur golden retriever, tous déguisés en vampires assortis, qui rient ensemble', true, 1536, 1024)}
      <div class="hero__txt">
        <span class="pastille-s">J-${joursAvant()} · Halloween tombe un samedi</span>
        <h1 id="h-hero">Toute la bande, <span>déguisée en 1 clic.</span></h1>
        <p class="sous">Des costumes assortis pour les parents, les enfants et même le chien. Choisissez un thème, ajoutez tout le monde, la remise se calcule toute seule.</p>
        <div class="hero__cta">
          <a class="btn btn--p" href="#/composer">Composer ma bande</a>
          <a class="btn btn--c" href="#/costumes">Voir les costumes</a>
        </div>
        <ul class="rea">
          <li>${ico.echange}Échange de taille gratuit</li>
          <li>${ico.camion}Livré avant le 31, garanti</li>
          <li>${ico.machine}Lavable en machine</li>
        </ul>
      </div>
    </div>
  </section>

  <section class="paliers wrap" aria-labelledby="h-pal">
    <div class="paliers__in">
      <div><p class="surtitre">Remise de groupe automatique</p><h2 id="h-pal">Plus vous êtes nombreux, moins c’est cher.</h2></div>
      <ul class="paliers__l">
        <li class="palier"><b>1–2</b><span>costumes au prix normal</span></li>
        <li class="palier palier--on"><b>−15 %</b><span>dès 3 costumes</span></li>
        <li class="palier palier--on"><b>−25 %</b><span>dès 4 costumes</span></li>
        <li class="palier"><b>9 €</b><span>le costume animal dès 2 costumes humains</span></li>
      </ul>
    </div>
  </section>

  <section class="themes wrap" aria-labelledby="h-themes">
    <div class="sec-tete rev">
      <div><p class="surtitre">6 thèmes de groupe</p><h2 id="h-themes">Un thème, toute la famille.</h2></div>
      <p>Chaque thème existe en version adulte, enfant et animal. Même tissu, mêmes couleurs : sur la photo, tout le monde va ensemble.</p>
    </div>
    <div class="themes__grille">
      ${Object.entries(THEMES).map(([k, t]) => `
      <a class="theme rev" href="#/composer/${k}">
        <div class="theme__img">${img('g-' + k, '', false, 1200, 800)}<span class="pastille-s">${t.tag}</span></div>
        <div class="theme__txt"><h3>${t.nom}</h3><p>${t.txt}</p>
          <div class="theme__prix"><span>Famille de 4 + animal : <span class="num">${eur(prixFamille(k))}</span></span><span class="lien">Composer</span></div></div>
      </a>`).join('')}
    </div>
  </section>

  <section class="etapes" aria-labelledby="h-etapes">
    <div class="wrap">
      <div class="sec-tete rev"><div><p class="surtitre">Comment ça marche</p><h2 id="h-etapes">Trois étapes, zéro prise de tête.</h2></div><p>Fini les allers-retours entre cinq sites et trois tailles différentes. Ici, tout se commande ensemble.</p></div>
      <div class="etapes__l">
        <div class="etape rev"><b>1</b><h3>Choisissez un thème</h3><p>Vampires, sorcières, potager, Olympe… Six univers déclinés pour tous les âges.</p>
          <div class="mini-config" aria-hidden="true"><div><span>Comte Nocturne · L</span><span>49 €</span></div><div><span>Comte Nocturne · M</span><span>49 €</span></div><div><span>Petit Comte · 6-7 ans</span><span>29 €</span></div><div><span>Cape pour chien · L</span><span>9 €</span></div><div class="tot"><span>−25 % appliqué</span><span>−41,75 €</span></div></div>
        </div>
        <div class="etape rev"><b>2</b><h3>Ajoutez chaque membre</h3><p>Adulte, enfant ou animal : une taille pour chacun, le prix se met à jour à chaque ajout.</p></div>
        <div class="etape rev"><b>3</b><h3>Recevez tout dans un seul colis</h3><p>Livré avant le 31 si vous commandez avant le 26 octobre. Une taille ne va pas ? Échange gratuit.</p></div>
      </div>
    </div>
  </section>

  <section class="prods wrap" aria-labelledby="h-best">
    <div class="sec-tete rev"><div><p class="surtitre">Les plus portés</p><h2 id="h-best">Ce que la bande adore cette année.</h2></div><a class="lien" href="#/costumes">Tous les costumes (18)</a></div>
    <div class="grille">${best.map(carte).join('')}</div>
  </section>

  <section class="animaux wrap" aria-labelledby="h-anim">
    <div class="animaux__g">
      <div class="animaux__imgs rev"><figure>${img('c-potager', 'Chien déguisé en citrouille')}</figure><figure>${img('c-vampire', 'Chien portant une cape de vampire')}</figure></div>
      <div class="rev">
        <p class="surtitre">Les animaux aussi</p>
        <h2 id="h-anim">Conçus pour qu’ils les gardent sur eux.</h2>
        <p>Un costume animal mal pensé finit arraché au bout de cinq minutes. Les nôtres sont testés sur de vrais chiens et chats, pour qu’ils oublient qu’ils les portent.</p>
        <ul class="coches">
          <li>${ico.coche}Yeux, oreilles et moustaches toujours dégagés</li>
          <li>${ico.coche}Fixation scratch, pas d’élastique qui serre</li>
          <li>${ico.coche}Ouverture pour la laisse et le harnais</li>
          <li>${ico.coche}À 9 € dès 2 costumes humains dans le panier</li>
        </ul>
        <a class="btn btn--n" href="#/costumes/animal">Voir les costumes animaux</a>
      </div>
    </div>
  </section>

  <section class="secu wrap" id="securite" aria-label="Sécurité et tailles">
    <div class="secu__g">
      <div class="bloc-c rev">
        <p class="surtitre">Sécurité des enfants</p>
        <h2>Visibles dans la rue, à l’aise toute la soirée.</h2>
        <p>La tournée des bonbons se fait souvent après le coucher du soleil. Nos costumes enfants intègrent des bandes réfléchissantes, les masques ne couvrent jamais tout le visage et tous nos tissus respectent la norme européenne EN 71-2 sur l’inflammabilité.</p>
        <div class="secu__img">${img('safety', 'Détail d’une cape d’enfant avec bande réfléchissante et seau lumineux en forme de citrouille', false, 1200, 900)}</div>
      </div>
      ${guideTailles()}
    </div>
  </section>

  <section class="avis wrap" aria-labelledby="h-avis">
    <div class="sec-tete rev"><div><p class="surtitre">#SpookySquad</p><h2 id="h-avis">Vos bandes, un soir d’octobre.</h2></div><p><b style="font-family:var(--f-titre);font-weight:400;font-size:var(--t-xl);color:var(--nuit)">4,8/5</b> sur 3 120 avis vérifiés</p></div>
    <div class="avis__g">
      ${[
        ['ugc-1','« On a enfin une photo de famille où tout le monde est assorti. Même le chien a gardé son chapeau toute la soirée. »','Émilie, Lille · Thème Sorcières'],
        ['ugc-2','« Mon fils était entre deux tailles, on a pris la plus grande comme conseillé : parfait, avec un pull dessous. »','Karim, Toulouse · Thème Potager'],
        ['ugc-3','« Six toges commandées pour une soirée entre amis, −25 % automatique, reçues en trois jours. »','Léa, Marseille · Thème Olympe']
      ].map(([i, q, c]) => `<figure class="avis__c rev">${img(i, '', false, 900, 1200)}<div><b style="color:#C95A0B" aria-label="5 sur 5">★★★★★</b><blockquote>${q}</blockquote><cite>${c}</cite></div></figure>`).join('')}
    </div>
  </section>

  <section class="news wrap" aria-labelledby="h-news">
    <div class="news__in rev">
      <div><h2 id="h-news">Le carnet de photos de groupe, offert.</h2><p>12 poses pour réussir la photo de famille d’Halloween, et −10 % sur votre bande.</p></div>
      <form id="form-news" novalidate>
        <label class="sr" for="email-news">Adresse e-mail</label>
        <div class="form-ligne"><input class="champ" id="email-news" type="email" autocomplete="email" placeholder="votre@email.fr" required aria-describedby="err-news"><button class="btn btn--n" type="submit">Je le veux</button></div>
        <p class="erreur" id="err-news" hidden>Saisissez une adresse e-mail valide, par exemple nom@domaine.fr.</p>
        <p class="aide">Un e-mail par semaine jusqu’au 31. Désinscription en un clic.</p>
      </form>
    </div>
  </section>

  <section class="faq wrap" id="faq" aria-labelledby="h-faq">
    <div class="faq__g">
      <div><p class="surtitre">Questions fréquentes</p><h2 id="h-faq" style="margin-top:.5rem">On vous répond.</h2></div>
      <div>
        ${[
          ['Et si la taille ne va pas ?', 'L’échange de taille est gratuit : on vous envoie la bonne taille avant même de recevoir l’ancienne, jusqu’au 30 octobre. Après Halloween, les retours restent gratuits pendant 30 jours.'],
          ['Serons-nous livrés avant Halloween ?', 'Oui, pour toute commande passée avant le dimanche 26 octobre à 23h59 en livraison standard, et avant le jeudi 29 octobre à midi en express. La date estimée s’affiche sur chaque fiche.'],
          ['Comment fonctionne la remise de groupe ?', 'Elle s’applique automatiquement au panier : −15 % dès 3 costumes, −25 % dès 4, tous thèmes confondus. Dès 2 costumes humains, jusqu’à 2 costumes animaux passent à 9 €.'],
          ['Les costumes enfants sont-ils sûrs ?', 'Tous nos tissus respectent la norme EN 71-2 (inflammabilité). Pas de cordon au cou, fermetures scratch, masques non intégraux et bandes réfléchissantes sur les modèles enfants.'],
          ['Combien coûte la livraison ?', `${eur(PORT_STD)} en standard, offerte dès ${eur(SEUIL)}. Express : ${eur(PORT_EXP)}.`]
        ].map(([q, r]) => `<details><summary>${q}</summary><p>${r}</p></details>`).join('')}
      </div>
    </div>
  </section>`;
}

function pageCostumes(filtre = 'tout') {
  const estRole = ROLES[filtre], estTheme = THEMES[filtre];
  const liste = P.filter(p => filtre === 'tout' || p.role === filtre || p.theme === filtre);
  const titre = filtre === 'tout' ? 'Tous les costumes' : estRole ? ({ adulte:'Costumes adultes', enfant:'Costumes enfants', animal:'Costumes animaux' })[filtre] : THEMES[filtre].nom;
  const intro = estTheme ? THEMES[filtre].txt : estRole === 'Animal' ? 'Yeux dégagés, scratch doux, ouverture pour la laisse. À 9 € dès 2 costumes humains dans le panier.' : estRole === 'Enfant' ? 'Du 2 ans au 12 ans. Bandes réfléchissantes, pas de cordon au cou, lavables en machine.' : '18 costumes, 6 thèmes, 3 versions. Mélangez librement, la remise de groupe s’applique à tout le panier.';
  return `<div class="wrap">
    <header class="page-tete"><nav class="fil" aria-label="Fil d’Ariane"><a href="#/">Accueil</a><span aria-hidden="true">/</span><span>${titre}</span></nav><h1>${titre}</h1><p>${intro}</p></header>
    <div class="filtres" role="group" aria-label="Filtrer">
      ${[['tout','Tout'],['adulte','Adultes'],['enfant','Enfants'],['animal','Animaux']].map(([k, n]) => `<a class="puce" role="button" href="#/costumes/${k === 'tout' ? '' : k}" aria-pressed="${k === filtre}">${n}</a>`).join('')}
      <span class="sep" aria-hidden="true"></span>
      ${Object.entries(THEMES).map(([k, t]) => `<a class="puce" role="button" href="#/costumes/${k}" aria-pressed="${k === filtre}">${t.court}</a>`).join('')}
    </div>
    <p style="font-size:var(--t-sm);color:var(--encre-3);font-weight:600;margin-bottom:1.2rem" aria-live="polite">${liste.length} costumes</p>
    <div class="grille" style="padding-bottom:3rem">${liste.map(carte).join('')}</div>
    <div class="bande-offre" style="margin-bottom:4rem;padding:1.5rem 1.8rem"><p style="font-size:var(--t-base)">Toute la famille dans le même thème ? <b>−25 % dès 4 costumes.</b></p><a class="btn btn--p" href="#/composer${estTheme ? '/' + filtre : ''}">Composer ma bande</a></div>
  </div>`;
}

function livraisonBloc() {
  const now = new Date(); const std = ouvres(now, 4), exp = ouvres(now, 2);
  return `<div class="info-box">
    <div>${ico.camion}<p><b>${now <= LIM_STD ? 'Livré avant le samedi 31, garanti.' : now <= LIM_EXP ? 'Encore livrable avant le 31 en express.' : 'Livraison sous 4 jours ouvrés.'}</b><br><span>Standard : ${jour(std)}${now <= LIM_EXP ? ' · Express : ' + jour(exp) : ''}</span></p></div>
    <div>${ico.echange}<p><b>Échange de taille gratuit.</b> <span>On envoie la nouvelle taille avant de récupérer l’ancienne.</span></p></div>
  </div>`;
}

function pageProduit(id) {
  const p = byId(id); if (!p || !p.role) return page404();
  const tailles = TAILLES[p.role]; const defT = tailles[Math.floor(tailles.length / 2)];
  const freres = ['adulte','enfant','animal'].filter(r => r !== p.role).map(r => byId(p.theme + '-' + r));
  return `<div class="wrap">
    <nav class="fil" aria-label="Fil d’Ariane" style="padding-top:1.4rem"><a href="#/">Accueil</a><span aria-hidden="true">/</span><a href="#/costumes/${p.theme}">${THEMES[p.theme].nom}</a><span aria-hidden="true">/</span><span>${esc(p.nom)}</span></nav>
    <div class="fiche">
      <div class="galerie">
        <figure>${img(p.img, p.nom + ', ' + ROLES[p.role].toLowerCase(), true)}</figure>
        <figure>${img('g-' + p.theme, 'Toute la famille dans le thème ' + THEMES[p.theme].nom, false, 1200, 800)}</figure>
        <figure>${img(freres[0].img, '')}</figure>
      </div>
      <div class="fiche__info">
        <span class="pastille-s" style="align-self:flex-start">${THEMES[p.theme].tag} · ${ROLES[p.role]}</span>
        <h1>${esc(p.nom)}</h1>
        ${etoiles(p.note, p.avis)}
        <p class="fiche__prix num">${eur(p.prix)}${p.role === 'animal' ? ' <span style="font-family:var(--f-corps);font-size:var(--t-sm);font-weight:800;color:var(--slime-f)">ou 9 € avec 2 costumes humains</span>' : ''}</p>
        <p class="fiche__desc">${p.desc}</p>
        <fieldset class="tailles"><legend><span>Taille</span><a class="lien" href="#/" data-scroll="tailles">Guide des tailles</a></legend>
          <div class="tailles__l">${tailles.map(t => `<label><input type="radio" name="taille" value="${t}"${t === defT ? ' checked' : ''}><span>${t}</span></label>`).join('')}</div>
        </fieldset>
        <p style="font-size:var(--t-xs);color:var(--encre-2);font-weight:600;margin-top:-.4rem">Entre deux tailles ? Prenez la plus grande.</p>
        <div class="achat"><button class="btn btn--p" id="btn-ajout">Ajouter au panier</button></div>
        <div class="bande-offre"><span>Habillez aussi le reste de la bande : <b>−25 % dès 4</b></span><a class="btn btn--c" style="min-height:42px;padding:.5rem 1rem" href="#/composer/${p.theme}">Compléter la bande</a></div>
        ${livraisonBloc()}
        <div class="acc">
          <details open><summary>Ce qui est inclus</summary><div>${p.desc}</div></details>
          <details><summary>Matières et entretien</summary><div>Polyester doux certifié OEKO-TEX, conforme EN 71-2. Lavable en machine à 30 °C, séchage à plat.</div></details>
          <details><summary>Livraison, échanges et retours</summary><div>Standard ${eur(PORT_STD)}, offerte dès ${eur(SEUIL)}. Express ${eur(PORT_EXP)}. Échange de taille gratuit, retours gratuits 30 jours.</div></details>
        </div>
      </div>
    </div>
    <section class="prods" aria-labelledby="h-fr" style="padding-top:1rem">
      <div class="sec-tete"><div><p class="surtitre">Le même thème</p><h2 id="h-fr">Pour le reste de la famille.</h2></div></div>
      <div class="grille">${freres.map(carte).join('')}${P.filter(x => x.role === p.role && x.theme !== p.theme).slice(0, 2).map(carte).join('')}</div>
    </section>
  </div>
  <div class="barre-mobile" id="barre-mobile"><div><b style="display:block;font-size:var(--t-sm)">${esc(p.nom.length > 26 ? p.nom.slice(0, 24) + '…' : p.nom)}</b><span class="num" style="font-size:var(--t-sm)">${eur(p.prix)}</span></div><button class="btn btn--p" id="btn-ajout-mob">Ajouter</button></div>`;
}

/* Configurateur */
const cfg = { theme: 'vampire', membres: [] }; // {role, taille, uid}
let uid = 0;
function initCfg(th) {
  if (th && THEMES[th] && th !== cfg.theme) cfg.theme = th;
  if (!cfg.membres.length) cfg.membres = [{ role:'adulte', taille:'M', uid:++uid }, { role:'adulte', taille:'L', uid:++uid }, { role:'enfant', taille:'6-7 ans', uid:++uid }];
}
function calcCfg() {
  const nb = cfg.membres.length, humains = cfg.membres.filter(m => m.role !== 'animal').length;
  const taux = nb >= 4 ? .25 : nb >= 3 ? .15 : 0; let promo = humains >= 2 ? 2 : 0;
  let brut = 0, net = 0;
  const lignes = cfg.membres.map(m => { const p = byId(cfg.theme + '-' + m.role); let n;
    if (m.role === 'animal' && promo > 0) { promo--; n = PRIX_ANIMAL; } else n = p.prix * (1 - taux);
    brut += p.prix; net += n; return { m, p, n }; });
  return { nb, humains, taux, brut, net, lignes };
}
function pageComposer(th) {
  initCfg(th);
  return `<div class="wrap">
    <header class="page-tete"><nav class="fil" aria-label="Fil d’Ariane"><a href="#/">Accueil</a><span aria-hidden="true">/</span><span>Composer ma bande</span></nav>
      <h1>Composez votre bande.</h1><p>Choisissez un thème, ajoutez chaque membre avec sa taille. La remise de groupe se calcule en direct.</p></header>
    <div class="config">
      <div>
        <section class="config__etape" aria-labelledby="e1"><h2 id="e1"><i>1</i>Le thème</h2>
          <div class="choix-themes">${Object.entries(THEMES).map(([k, t]) => `<button class="choix-theme" data-theme="${k}" aria-pressed="${k === cfg.theme}">${img('g-' + k, '', false, 1200, 800)}<span>${t.nom}</span></button>`).join('')}</div>
        </section>
        <section class="config__etape" aria-labelledby="e2"><h2 id="e2"><i>2</i>Les membres de la bande</h2>
          <div class="ajout-membres" id="ajout-membres"></div>
          <div class="membres" id="membres" aria-live="polite"></div>
        </section>
      </div>
      <aside class="resume" id="resume" aria-label="Récapitulatif de la bande"></aside>
    </div>
  </div>`;
}
function rendreCfg() {
  const t = cfg.theme;
  $('#ajout-membres').innerHTML = ['adulte','enfant','animal'].map(r => { const p = byId(t + '-' + r); return `<button class="ajout-m" data-ajout-m="${r}"><img src="img/${p.img}.webp" alt="" width="38" height="38">+ ${ROLES[r]} <small class="num">${eur(p.prix)}</small></button>`; }).join('');
  const k = calcCfg();
  $('#membres').innerHTML = k.lignes.length ? k.lignes.map(({ m, p, n }, i) => `
    <div class="membre">
      <img src="img/${p.img}.webp" alt="" width="56" height="56">
      <div><b>${ROLES[m.role]} ${cfg.membres.filter((x, j) => x.role === m.role && j <= i).length}</b><small>${esc(p.nom)}</small></div>
      <label class="sr" for="t-${m.uid}">Taille</label>
      <select id="t-${m.uid}" data-taille="${m.uid}">${TAILLES[m.role].map(s => `<option${s === m.taille ? ' selected' : ''}>${s}</option>`).join('')}</select>
      <div class="prix num">${eur(n)}${n < p.prix - .001 ? `<s>${eur(p.prix)}</s>` : ''}</div>
      <button class="suppr" data-suppr-m="${m.uid}" aria-label="Retirer ce membre">${ico.x}</button>
    </div>`).join('') : `<p class="vide-m">Ajoutez un premier membre avec les boutons ci-dessus.</p>`;
  $('#resume').innerHTML = `
    <div class="resume__img">${img('g-' + t, '', false, 1200, 800)}</div>
    <h2>${THEMES[t].nom}</h2>
    <div><p class="msg" aria-live="polite">${msgPalier(k.nb, k.humains)}</p>${jauge(k.nb)}<div class="jauge-l" style="margin-top:.4rem"><span>1</span><span>3 : −15 %</span><span>4+ : −25 %</span></div></div>
    <div class="ligne-t"><span>${k.nb} costume${k.nb > 1 ? 's' : ''}</span><span class="num">${eur(k.brut)}</span></div>
    ${k.brut - k.net > .001 ? `<div class="ligne-t eco"><span>Remise de groupe</span><span class="num">−${eur(k.brut - k.net)}</span></div>` : ''}
    <div class="ligne-t g"><span>Total de la bande</span><span class="num">${eur(k.net)}</span></div>
    <button class="btn btn--p btn--plein" id="ajout-bande"${k.nb ? '' : ' disabled'}>Ajouter toute la bande au panier</button>
    <p style="font-size:var(--t-xs);opacity:.8;text-align:center">Échange de taille gratuit pour chaque membre</p>`;
}

function pageCommande() {
  if (!panier.length) return `<div class="wrap merci"><h1>Votre panier est vide</h1><p>Composez votre bande avant de passer commande.</p><p style="margin-top:2rem"><a class="btn btn--p" href="#/composer">Composer ma bande</a></p></div>`;
  const k = calcul(), now = new Date(), port = k.net >= SEUIL ? 0 : PORT_STD;
  const ch = (id, lab, ac, extra = '', err = 'Champ requis.', cls = '') => `<div class="${cls}"><label for="${id}">${lab}</label><input class="champ" id="${id}" autocomplete="${ac}" required ${extra}><p class="erreur" hidden>${err}</p></div>`;
  return `<div class="wrap">
    <nav class="fil" aria-label="Fil d’Ariane" style="padding-top:1.4rem"><a href="#/">Accueil</a><span aria-hidden="true">/</span><span>Commande</span></nav>
    <div class="commande">
      <form id="form-cmd" novalidate>
        <h1>Plus qu’une étape.</h1>
        <fieldset class="bloc"><legend>Contact</legend><div class="champs">${ch('c-email', 'E-mail', 'email', 'type="email"', 'Adresse e-mail invalide.', 'plein')}</div></fieldset>
        <fieldset class="bloc"><legend>Livraison</legend><div class="champs">
          ${ch('c-prenom', 'Prénom', 'given-name')}${ch('c-nom', 'Nom', 'family-name')}${ch('c-adr', 'Adresse', 'street-address', '', 'Champ requis.', 'plein')}${ch('c-cp', 'Code postal', 'postal-code', 'inputmode="numeric"', '5 chiffres.')}${ch('c-ville', 'Ville', 'address-level2')}
        </div>
        <div style="margin-top:1rem">
          <label class="option"><input type="radio" name="liv" value="std" checked><div>Standard, 4 jours ouvrés<small>Estimée le ${jour(ouvres(now, 4))}${now <= LIM_STD ? ' · avant le 31, garanti' : ''}</small></div><b class="num">${port ? eur(port) : 'Offerte'}</b></label>
          <label class="option"><input type="radio" name="liv" value="exp"><div>Express, 2 jours ouvrés<small>Estimée le ${jour(ouvres(now, 2))}</small></div><b class="num">${eur(PORT_EXP)}</b></label>
        </div></fieldset>
        <fieldset class="bloc"><legend>Paiement</legend><div class="champs">
          ${ch('c-carte', 'Numéro de carte', 'cc-number', 'inputmode="numeric" placeholder="1234 5678 9012 3456"', 'Numéro de carte incomplet.', 'plein')}${ch('c-exp', 'Expiration', 'cc-exp', 'placeholder="MM/AA"', 'Format MM/AA.')}${ch('c-cvc', 'CVC', 'cc-csc', 'inputmode="numeric" placeholder="123"', '3 chiffres.')}
        </div></fieldset>
        <button class="btn btn--p btn--plein" type="submit" id="payer">Payer ${eur(k.net + port)}</button>
        <p class="securite" style="margin-top:.8rem">${ico.cadenas} Paiement chiffré · Échange de taille gratuit</p>
      </form>
      <aside class="recap" aria-labelledby="h-recap">
        <h2 id="h-recap">Votre bande</h2>
        ${k.lignes.map(({ l, p, net }) => `<div class="ligne">${p.img ? `<img src="img/${p.img}.webp" alt="" width="52" height="64">` : '<span></span>'}<div><h3>${esc(p.nom)}</h3><small>${p.role ? ROLES[p.role] + ' · ' + esc(l.taille) : 'Accessoire'} · × ${l.qte}</small></div><div class="ligne__d"><span class="num">${eur(net)}</span></div></div>`).join('')}
        <div class="recap__tot">
          <div class="tot"><span>Sous-total</span><span class="num">${eur(k.brut)}</span></div>
          ${k.eco > 0 ? `<div class="tot tot--r"><span>Remise de groupe</span><span class="num">−${eur(k.eco)}</span></div>` : ''}
          <div class="tot"><span>Livraison</span><span id="r-port">${port ? eur(port) : 'Offerte'}</span></div>
          <div class="tot tot--g"><span>Total TTC</span><span class="num" id="r-tot">${eur(k.net + port)}</span></div>
        </div>
      </aside>
    </div></div>`;
}
const pageMerci = n => `<div class="wrap merci"><span class="pastille-s">Commande confirmée</span><h1>La bande est au complet.</h1><p>Un e-mail de confirmation arrive avec le suivi. Votre colis part sous 24 h. Une taille ne va pas ? Répondez simplement à l’e-mail, on s’occupe de l’échange.</p><span class="num-cmd num">Commande n° ${esc(n)}</span><p><a class="btn btn--g" href="#/costumes">Continuer mes achats</a></p></div>`;
const page404 = () => `<div class="wrap merci"><h1>Cette page s’est déguisée en fantôme.</h1><p>Elle a disparu. Revenez aux costumes.</p><p style="margin-top:2rem"><a class="btn btn--p" href="#/costumes">Voir les costumes</a></p></div>`;

/* ---------- Routage ---------- */
function route() {
  const h = location.hash.replace(/^#\/?/, ''); const [seg, arg] = h.split('/');
  let html;
  if (!seg) html = pageAccueil();
  else if (seg === 'costumes') html = pageCostumes(arg && (ROLES[arg] || THEMES[arg]) ? arg : 'tout');
  else if (seg === 'produit') html = pageProduit(arg);
  else if (seg === 'composer') html = pageComposer(arg);
  else if (seg === 'commande') html = pageCommande();
  else if (seg === 'merci') html = pageMerci(arg || '');
  else html = page404();
  $('#main').innerHTML = html;
  $$('.nav a').forEach(a => a.toggleAttribute('aria-current', !a.dataset.scroll && a.getAttribute('href') === '#/' + h.replace(/\/$/, '')));
  $$('.nav a[aria-current]').forEach(a => a.setAttribute('aria-current', 'page'));
  document.title = seg === 'produit' && $('.fiche h1') ? $('.fiche h1').textContent + ' — Spooky Squad' : ({ '':'Spooky Squad — Costumes d’Halloween assortis pour toute la famille', costumes:'Costumes — Spooky Squad', composer:'Composer ma bande — Spooky Squad', commande:'Commande — Spooky Squad', merci:'Merci — Spooky Squad' })[seg || ''] || 'Spooky Squad';
  if (!window.__cible) window.scrollTo(0, 0);
  apparitions(); monter(seg);
  if (window.__cible) { const c = document.getElementById(window.__cible); window.__cible = null; if (c) setTimeout(() => c.scrollIntoView({ behavior:'smooth' }), 40); }
}
let obs;
function apparitions() {
  if (obs) obs.disconnect();
  if (!('IntersectionObserver' in window) || matchMedia('(prefers-reduced-motion: reduce)').matches) { $$('.rev').forEach(e => e.classList.add('in')); return; }
  obs = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); obs.unobserve(e.target); } }), { rootMargin:'0px 0px -8% 0px' });
  $$('.rev').forEach(e => obs.observe(e));
}
const reEmail = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
function monter(seg) {
  const fn = $('#form-news');
  if (fn) fn.addEventListener('submit', e => { e.preventDefault(); const i = $('#email-news'), ok = reEmail.test(i.value.trim()); i.setAttribute('aria-invalid', String(!ok)); $('#err-news').hidden = ok; if (ok) fn.innerHTML = '<p class="succes" role="status">C’est parti. Le carnet et votre code de −10 % arrivent dans votre boîte mail.</p>'; });
  $$('[data-onglet]').forEach(b => b.addEventListener('click', () => { $$('[data-onglet]').forEach(x => x.setAttribute('aria-selected', String(x === b))); $$('[data-panneau]').forEach(p => p.hidden = p.dataset.panneau !== b.dataset.onglet); }));
  const hi = $('#haut'); if (hi) hi.addEventListener('input', () => { $('#reco-out').textContent = recoTaille(+hi.value); });
  if (seg === 'produit') {
    const id = location.hash.split('/')[2]; const t = () => ($('input[name="taille"]:checked') || {}).value;
    const go = () => { ajouter(id, t()); };
    $('#btn-ajout').addEventListener('click', go); $('#btn-ajout-mob').addEventListener('click', go);
    const bm = $('#barre-mobile'); new IntersectionObserver(([e]) => bm.classList.toggle('vis', !e.isIntersecting && e.boundingClientRect.top < 0)).observe($('#btn-ajout'));
  }
  if (seg === 'composer') {
    rendreCfg();
    const zone = $('#main');
    if (zone.__cfg) return; zone.__cfg = true;
    zone.addEventListener('click', e => {
      if (!location.hash.startsWith('#/composer')) return;
      const th = e.target.closest('[data-theme]'); if (th) { cfg.theme = th.dataset.theme; $$('[data-theme]').forEach(b => b.setAttribute('aria-pressed', String(b === th))); history.replaceState(null, '', '#/composer/' + cfg.theme); rendreCfg(); return; }
      const am = e.target.closest('[data-ajout-m]'); if (am) { if (cfg.membres.length >= 10) { toast('10 membres maximum par bande.'); return; } const r = am.dataset.ajoutM; cfg.membres.push({ role:r, taille:TAILLES[r][Math.floor(TAILLES[r].length / 2)], uid:++uid }); rendreCfg(); return; }
      const sm = e.target.closest('[data-suppr-m]'); if (sm) { cfg.membres = cfg.membres.filter(m => m.uid !== +sm.dataset.supprM); rendreCfg(); return; }
      if (e.target.closest('#ajout-bande')) {
        cfg.membres.forEach(m => ajouter(cfg.theme + '-' + m.role, m.taille, 1, false));
        toast(cfg.membres.length + ' costumes ajoutés, remise appliquée.'); ouvrirPanier();
      }
    });
    zone.addEventListener('change', e => { const s = e.target.closest('[data-taille]'); if (s) { const m = cfg.membres.find(x => x.uid === +s.dataset.taille); if (m) m.taille = s.value; } });
  }
  const fc = $('#form-cmd');
  if (fc) {
    const k = calcul();
    const maj = () => { const exp = $('input[name="liv"]:checked').value === 'exp'; const port = exp ? PORT_EXP : (k.net >= SEUIL ? 0 : PORT_STD); $('#r-port').textContent = port ? eur(port) : 'Offerte'; $('#r-tot').textContent = eur(k.net + port); $('#payer').textContent = 'Payer ' + eur(k.net + port); };
    $$('input[name="liv"]').forEach(r => r.addEventListener('change', maj));
    const regles = { 'c-email': x => reEmail.test(x), 'c-cp': x => /^\d{5}$/.test(x), 'c-carte': x => x.replace(/\s/g, '').length >= 15, 'c-exp': x => /^(0[1-9]|1[0-2])\/\d{2}$/.test(x), 'c-cvc': x => /^\d{3,4}$/.test(x) };
    const valide = i => { const ok = (regles[i.id] || (x => x.length > 0))(i.value.trim()); i.setAttribute('aria-invalid', String(!ok)); i.nextElementSibling.hidden = ok; return ok; };
    $$('.champ', fc).forEach(i => i.addEventListener('input', () => { if (i.getAttribute('aria-invalid') === 'true') valide(i); }));
    $('#c-carte').addEventListener('input', e => { e.target.value = e.target.value.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim(); });
    $('#c-exp').addEventListener('input', e => { let v = e.target.value.replace(/\D/g, '').slice(0, 4); if (v.length > 2) v = v.slice(0, 2) + '/' + v.slice(2); e.target.value = v; });
    fc.addEventListener('submit', e => {
      e.preventDefault(); const champs = $$('.champ', fc); const oks = champs.map(valide); const i = oks.indexOf(false);
      if (i >= 0) { champs[i].focus(); toast('Vérifiez les champs signalés.'); return; }
      const b = $('#payer'); b.disabled = true; b.textContent = 'Paiement en cours…';
      setTimeout(() => { const n = 'SQ-' + Math.floor(100000 + Math.random() * 900000); panier.length = 0; cfg.membres = []; majCompteur(); rendrePanier(); location.hash = '#/merci/' + n; }, 1100);
    });
  }
}

/* ---------- Événements globaux ---------- */
document.addEventListener('click', e => {
  const a = e.target.closest('[data-ajout]'); if (a) { e.preventDefault(); ajouter(a.dataset.ajout); return; }
  const ac = e.target.closest('[data-acc]'); if (ac) { ajouter(ac.dataset.acc, '', 1, false); toast('Accessoire ajouté.'); return; }
  const q = e.target.closest('[data-q]'); if (q) { modifier(q.dataset.cle, +q.dataset.q); return; }
  const s = e.target.closest('[data-suppr]'); if (s) { const l = panier.find(x => x.cle === s.dataset.suppr); if (l) modifier(l.cle, -l.qte); return; }
  if (e.target.closest('[data-ferme]')) fermerPanier();
  const sc = e.target.closest('[data-scroll]');
  if (sc) { e.preventDefault(); if (!location.hash || location.hash === '#/') { const c = document.getElementById(sc.dataset.scroll); if (c) c.scrollIntoView({ behavior:'smooth' }); } else { window.__cible = sc.dataset.scroll; location.hash = '#/'; } }
});
$('#ouvrir-panier').addEventListener('click', ouvrirPanier);
$('#fermer-panier').addEventListener('click', fermerPanier);
$('#voile').addEventListener('click', fermerPanier);
document.addEventListener('keydown', e => {
  const t = $('#tiroir'); if (!t.classList.contains('ouvert')) return;
  if (e.key === 'Escape') fermerPanier();
  if (e.key === 'Tab') { const f = $$('a[href],button:not([disabled]),input,select', t); if (!f.length) return; const a = f[0], z = f[f.length - 1];
    if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); } else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); } }
});
window.addEventListener('hashchange', route);
(() => { const now = new Date(), el = $('#annonce-texte');
  if (now > HALLOWEEN) el.innerHTML = '<b>Déstockage : −50 % sur tous les costumes</b> · Retours gratuits 30 jours';
  else if (now > LIM_STD) el.innerHTML = '<b>Dernière chance</b> · Livraison express avant le samedi 31 pour toute commande avant jeudi midi'; })();
rendrePanier(); route();
})();
